Aranya Meas
860971949
ameas001@ucr.edu


To run:
$make
$assn2

wasd to move the fish. It changes the velocity, so the fish can go really fast
and is uncontrollable sometimes.
You can press q to stop it completely.

DID NOT IMPLEMENT:
the seaweed returns to a static, upright stance after a point of time, but not a short amount of time
"o" key

EXTRA CREDIT:
I made a simple school of fish
